package sequence;
//Importamos los elementos necesarios que serian : FileInputStream, IOException, InputStream, SequenceInputStream
//FileInputStream: Se utilizan para representar ficheros de texto accedidos en orden secuencial, byte a byte
import java.io.FileInputStream;
import java.io.IOException;
//InputStream: recibe parametro y lee los bytes en secuencia de entrada
import java.io.InputStream;
//SequenceInputStream: combina dos o mas InputStream en uno. Primero el Sequence leera todos los bytes del primer Input, luego todos los bytes del segundo.
import java.io.SequenceInputStream;


/**
 *
 * @author Antonio Jose Adamuz Sereno
 * Name: Sequence.java
 * Descripcion: Programa para explicar el funcionamiento de SequenceInputStream 
 * a traves de la combinacion de dos archibos para pasarlos en bytes y ver en 
 * pantalla como los lee los dos como en orden tambien transforma los bytes en 
 * caracteres
 * 
 */
public class Sequence {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws IOException {
        // Creamos dos InputStream el input1 y el input 2. Se pueden crear mas para poder combinarlos pero en este caso lo haremos con 2 
        InputStream input1;
        InputStream input2;
            // En cada input crearemos un nuevo FileInputStream que cogera un archivo que lo pasemos y lo pasara a bytes
            input1 = new FileInputStream("c:\\prueba\\file1.txt");
            input2 = new FileInputStream("c:\\prueba\\file2.txt");
       
        
        //Creamos el SequenceInputStream y le pasamos los Input 1 y 2
        SequenceInputStream sequenceInputStream =
            new SequenceInputStream(input1, input2);
        //Creamos un int donde pasaremos los bytes leidos de cada archivo por el sequenceInputStream.
        int data = sequenceInputStream.read();
        //Hacemos un while cuando data sea distinto de -1 seguira haciendolo pero si da -1 significa que no hay mas datos para leer y el sequence devolvera -1
        while(data != -1){
            //Aqui mostrara por pantalla los bytes optenidos de cada lectura. 
            //System.out.println(data);
            //Aqui lo que hara es coger los bytes y convertirlos en caracteres.
            System.out.print((char)data); 
            //Aqui a data le volveremos a pasar el seuquenceInputStream.read() para que siga leyendo hasta que sata de -1 y cierre el bucle
            data = sequenceInputStream.read();
        }
        //En esta linea lo que haremos sera cerrar el sequenceInputStream antes de que finalize el programa
        sequenceInputStream.close();
    }
    
}
